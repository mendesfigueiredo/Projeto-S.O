#include <iostream>
#include <stdio.h>
#include <string.h>

struct Join{
    void teste(){
        int n;
        do{
            scanf("%d", &n);
            char nome;
            int timeJoin, timeProcess;

            scanf();

        }while(n > 1 && n < 16);
    }
};


int main(){
    struct Join entradaUm;

    entradaUm.teste();
}
